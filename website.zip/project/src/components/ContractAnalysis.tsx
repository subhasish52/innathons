import React, { useState } from 'react';
import axios from 'axios';
import { Upload, AlertTriangle } from 'lucide-react';

export const ContractAnalysis: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [analysis, setAnalysis] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const analyzeContract = async () => {
    if (!file) return;

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      // Replace with your actual API endpoint
      const response = await axios.post('/api/analyze-contract', formData);
      setAnalysis(response.data.analysis);
    } catch (error) {
      console.error('Error analyzing contract:', error);
      setAnalysis('Error analyzing contract. Please try again.');
    }
    setLoading(false);
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg">
      <div className="flex items-center space-x-2 mb-4">
        <AlertTriangle className="text-yellow-500" />
        <h3 className="text-xl font-semibold text-yellow-500">Contract Analysis</h3>
      </div>
      
      <div className="space-y-4">
        <div className="border-2 border-dashed border-gray-600 rounded-lg p-6 text-center">
          <input
            type="file"
            onChange={handleFileChange}
            className="hidden"
            id="contract-file"
            accept=".pdf,.png,.jpg,.jpeg"
          />
          <label
            htmlFor="contract-file"
            className="cursor-pointer flex flex-col items-center"
          >
            <Upload className="w-12 h-12 text-gray-400 mb-2" />
            <span className="text-sm text-gray-400">
              {file ? file.name : 'Upload contract document or image'}
            </span>
          </label>
        </div>

        {file && (
          <button
            onClick={analyzeContract}
            disabled={loading}
            className="w-full bg-yellow-500 text-gray-900 py-2 rounded font-medium hover:bg-yellow-400 disabled:opacity-50"
          >
            {loading ? 'Analyzing...' : 'Analyze Contract'}
          </button>
        )}

        {analysis && (
          <div className="bg-gray-700 p-4 rounded-lg">
            <h4 className="font-semibold mb-2">Analysis Result:</h4>
            <p className="text-sm text-gray-300 whitespace-pre-wrap">{analysis}</p>
          </div>
        )}
      </div>
    </div>
  );
};