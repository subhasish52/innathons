import React, { useState, useEffect } from 'react';
import { BarChart3, FileText, AlertTriangle, Calendar, Home, Contact as FileContract, Target, Phone, User, Moon, Mail, X } from 'lucide-react';
import { RevenueChart } from './components/RevenueChart';
import { RevenueEntry } from './components/RevenueEntry';
import { ContractAnalysis } from './components/ContractAnalysis';
import { Auth } from './components/Auth';
import { Contact } from './components/Contact';
import { ContractDetails } from './components/ContractDetails';
import { agreements, monthlyRevenue as initialMonthlyRevenue } from './data';
import { MonthlyRevenue } from './types';

function App() {
  const [authenticated, setAuthenticated] = useState(false);
  const [activeSection, setActiveSection] = useState('dashboard');
  const [showCashFlow, setShowCashFlow] = useState(false);
  const [showAgreements, setShowAgreements] = useState(false);
  const [monthlyRevenue, setMonthlyRevenue] = useState(initialMonthlyRevenue);
  const [showRevenueEntry, setShowRevenueEntry] = useState(false);
  const [selectedContract, setSelectedContract] = useState(null);
  
  const totalRevenue = 500000;
  const activeAgreements = 45;
  const upcomingRenewals = 7;
  const complianceRisks = 3;
  const fasScore = 87;

  useEffect(() => {
    // Check if user is authenticated
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setAuthenticated(!!session);
    };
    checkAuth();
  }, []);

  const handleAddRevenue = (newRevenue: MonthlyRevenue) => {
    setMonthlyRevenue([...monthlyRevenue, newRevenue]);
  };

  if (!authenticated) {
    return <Auth onAuthSuccess={() => setAuthenticated(true)} />;
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Navigation */}
      <nav className="bg-gray-800 p-4">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex space-x-6">
            <button 
              className={"flex items-center space-x-2 " + (activeSection === 'dashboard' ? 'text-yellow-500' : 'text-white')}
              onClick={() => setActiveSection('dashboard')}
            >
              <Home size={20} />
              <span>Home</span>
            </button>
            <button 
              className={"flex items-center space-x-2 " + (activeSection === 'contracts' ? 'text-yellow-500' : 'text-white')}
              onClick={() => setActiveSection('contracts')}
            >
              <FileContract size={20} />
              <span>Contracts</span>
            </button>
            <button 
              className={"flex items-center space-x-2 " + (activeSection === 'track' ? 'text-yellow-500' : 'text-white')}
              onClick={() => setActiveSection('track')}
            >
              <Target size={20} />
              <span>Track</span>
            </button>
            <button 
              className={"flex items-center space-x-2 " + (activeSection === 'contact' ? 'text-yellow-500' : 'text-white')}
              onClick={() => setActiveSection('contact')}
            >
              <Phone size={20} />
              <span>Contact</span>
            </button>
          </div>
          <div className="flex items-center space-x-4">
            <button className="flex items-center space-x-2">
              <Moon size={20} />
              <span>Dark Mode: ON</span>
            </button>
            <div className="relative group">
              <button className="flex items-center space-x-2">
                <User size={20} />
                <span>Profile</span>
              </button>
              <div className="absolute right-0 mt-2 w-48 bg-gray-800 rounded-md shadow-lg hidden group-hover:block">
                <div className="py-1">
                  <a href="#profile" className="block px-4 py-2 text-sm hover:bg-gray-700">My Profile</a>
                  <a href="#logout" className="block px-4 py-2 text-sm hover:bg-gray-700">Log Out</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {activeSection === 'dashboard' && (
          <>
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-yellow-500 mb-2">Dashboard</h1>
              <p className="text-gray-400">Welcome to the Agreement Management Dashboard</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {/* Total Revenue Card */}
              <div 
                className="bg-gray-800 p-6 rounded-lg cursor-pointer hover:bg-gray-700 transition"
                onClick={() => setShowCashFlow(!showCashFlow)}
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-yellow-500">Total Revenue</h3>
                  <BarChart3 className="text-yellow-500" />
                </div>
                <p className="text-3xl font-bold">${totalRevenue.toLocaleString()}</p>
                <p className="text-sm text-gray-400">Generated from active agreements</p>
                
                {showCashFlow && (
                  <div className="mt-4">
                    <div className="bg-gray-700 p-4 rounded space-y-4">
                      <RevenueChart data={monthlyRevenue} />
                      <button
                        onClick={() => setShowRevenueEntry(!showRevenueEntry)}
                        className="w-full bg-gray-600 text-white py-2 rounded hover:bg-gray-500"
                      >
                        {showRevenueEntry ? 'Hide Entry Form' : 'Add Revenue Data'}
                      </button>
                      {showRevenueEntry && (
                        <RevenueEntry onAddRevenue={handleAddRevenue} />
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Active Agreements Card */}
              <div 
                className="bg-gray-800 p-6 rounded-lg cursor-pointer hover:bg-gray-700 transition"
                onClick={() => setShowAgreements(!showAgreements)}
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-yellow-500">Active Agreements</h3>
                  <FileText className="text-yellow-500" />
                </div>
                <p className="text-3xl font-bold">{activeAgreements}</p>
                <p className="text-sm text-gray-400">Currently in effect</p>
                
                {showAgreements && (
                  <div className="mt-4">
                    <div className="bg-gray-700 p-4 rounded">
                      <h4 className="text-sm font-semibold mb-2">Status</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>Active</span>
                          <span className="text-green-500">42</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Expired</span>
                          <span className="text-red-500">3</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Upcoming Renewals Card */}
              <div className="bg-gray-800 p-6 rounded-lg hover:bg-gray-700 transition">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-yellow-500">Upcoming Renewals</h3>
                  <Calendar className="text-yellow-500" />
                </div>
                <p className="text-3xl font-bold">{upcomingRenewals}</p>
                <p className="text-sm text-gray-400">Due in the next 30 days</p>
                <p className="text-xs text-red-400 mt-2">Penalty applies after 30 days</p>
              </div>

              {/* Compliance Risks Card */}
              <div className="bg-gray-800 p-6 rounded-lg hover:bg-gray-700 transition">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-yellow-500">Compliance Risks</h3>
                  <AlertTriangle className="text-yellow-500" />
                </div>
                <p className="text-3xl font-bold">{complianceRisks}</p>
                <p className="text-sm text-gray-400">Potential issues detected</p>
              </div>
            </div>

            {/* Contract Analysis Section */}
            <div className="mb-8">
              <ContractAnalysis />
            </div>

            {/* FAS Score Section */}
            <div className="bg-gray-800 p-8 rounded-lg">
              <h3 className="text-2xl font-bold text-yellow-500 text-center mb-6">FAS Score</h3>
              <div className="flex justify-center mb-6">
                <div className="relative w-48 h-48">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-4xl font-bold">{fasScore}</div>
                  </div>
                  <svg className="w-full h-full" viewBox="0 0 36 36">
                    <path
                      d="M18 2.0845
                        a 15.9155 15.9155 0 0 1 0 31.831
                        a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="#fbbf24"
                      strokeWidth="3"
                      strokeDasharray={`${fasScore}, 100`}
                    />
                  </svg>
                </div>
              </div>
              <div className="text-center mb-6">
                <p className="text-lg font-semibold">Interpretation:</p>
                <p className="text-gray-400">High-Performing Agreement</p>
                <p className="text-gray-400">Optimized for revenue, liquidity, and compliance.</p>
              </div>
              <div className="grid grid-cols-2 gap-4 max-w-2xl mx-auto">
                <div className="text-center">
                  <p className="font-semibold">Monetization</p>
                  <p className="text-gray-400">28/30</p>
                </div>
                <div className="text-center">
                  <p className="font-semibold">Risk Compliance</p>
                  <p className="text-gray-400">20/25</p>
                </div>
                <div className="text-center">
                  <p className="font-semibold">Execution Efficiency</p>
                  <p className="text-gray-400">19/20</p>
                </div>
                <div className="text-center">
                  <p className="font-semibold">AI Utilization</p>
                  <p className="text-gray-400">9/10</p>
                </div>
              </div>
            </div>
          </>
        )}

        {activeSection === 'track' && (
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-yellow-500 mb-6">License Tracking</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-gray-800 p-6 rounded-lg">
                <h3 className="text-xl font-semibold text-yellow-500 mb-4">Essential Licenses</h3>
                <p className="text-3xl font-bold">15</p>
                <p className="text-sm text-gray-400">Active essential licenses</p>
              </div>
              <div className="bg-gray-800 p-6 rounded-lg">
                <h3 className="text-xl font-semibold text-yellow-500 mb-4">Essential Pay</h3>
                <p className="text-3xl font-bold">$250,000</p>
                <p className="text-sm text-gray-400">Total essential costs</p>
              </div>
              <div className="bg-gray-800 p-6 rounded-lg cursor-pointer" onClick={() => alert("Optional licenses are additional features or services that enhance your operations but aren't critical to core business functions.")}>
                <h3 className="text-xl font-semibold text-yellow-500 mb-4">Optional Licenses</h3>
                <p className="text-3xl font-bold">8</p>
                <p className="text-sm text-gray-400">Click for more info</p>
              </div>
            </div>

            {/* Detailed License List */}
            <div className="bg-gray-800 rounded-lg overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-semibold text-yellow-500 mb-4">License Details</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-700">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Name</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Type</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Value</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Renewal Date</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Payment Due</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Risk Level</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-700">
                    {agreements.map((agreement) => (
                      <tr key={agreement.id} className="hover:bg-gray-700">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="text-sm font-medium">{agreement.name}</div>
                            <div className="text-sm text-gray-400">{agreement.details}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">{agreement.type}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            agreement.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {agreement.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          ${agreement.value.toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">{agreement.renewalDate}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">{agreement.paymentDue}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            agreement.riskLevel === 'low' ? 'bg-green-100 text-green-800' :
                            agreement.riskLevel === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {agreement.riskLevel}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeSection === 'contact' && <Contact />}

        {/* Add contract details view when a contract is selected */}
        {selectedContract && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-gray-900 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <ContractDetails agreement={selectedContract} />
              <button
                onClick={() => setSelectedContract(null)}
                className="absolute top-4 right-4 text-gray-400 hover:text-white"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;