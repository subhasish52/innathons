import { Agreement, MonthlyRevenue } from './types';

export const agreements: Agreement[] = [
  {
    id: 1,
    name: "Software License A",
    status: "active",
    renewalDate: "2024-04-15",
    type: "essential",
    value: 50000,
    details: "Enterprise-wide software license for core business operations",
    paymentDue: "2024-03-15",
    riskLevel: "low"
  },
  {
    id: 2,
    name: "Vendor Agreement B",
    status: "active",
    renewalDate: "2024-04-20",
    type: "optional",
    value: 25000,
    details: "Third-party service integration license",
    paymentDue: "2024-03-20",
    riskLevel: "medium"
  },
  {
    id: 3,
    name: "Cloud Infrastructure License",
    status: "active",
    renewalDate: "2024-05-01",
    type: "essential",
    value: 75000,
    details: "Cloud platform and services license",
    paymentDue: "2024-04-01",
    riskLevel: "high"
  }
];

export const monthlyRevenue: MonthlyRevenue[] = [
  { month: "Jan", inflow: 120000, outflow: 80000 },
  { month: "Feb", inflow: 150000, outflow: 90000 },
  { month: "Mar", inflow: 180000, outflow: 85000 },
  { month: "Apr", inflow: 160000, outflow: 95000 },
  { month: "May", inflow: 200000, outflow: 100000 },
  { month: "Jun", inflow: 190000, outflow: 88000 }
];