export interface Agreement {
  id: number;
  name: string;
  status: 'active' | 'expired';
  renewalDate: string;
  type: 'essential' | 'optional';
  value: number;
  details: string;
  paymentDue: string;
  riskLevel: 'low' | 'medium' | 'high';
  eventScore?: number;
  analysis?: string;
}

export interface MonthlyRevenue {
  month: string;
  inflow: number;
  outflow: number;
}

export interface User {
  id: string;
  email: string;
  name?: string;
  company?: string;
}