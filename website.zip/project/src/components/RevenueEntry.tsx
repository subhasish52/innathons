import React, { useState } from 'react';
import { MonthlyRevenue } from '../types';

interface RevenueEntryProps {
  onAddRevenue: (revenue: MonthlyRevenue) => void;
}

export const RevenueEntry: React.FC<RevenueEntryProps> = ({ onAddRevenue }) => {
  const [month, setMonth] = useState('');
  const [inflow, setInflow] = useState('');
  const [outflow, setOutflow] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (month && inflow && outflow) {
      onAddRevenue({
        month,
        inflow: Number(inflow),
        outflow: Number(outflow)
      });
      setMonth('');
      setInflow('');
      setOutflow('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-gray-700 p-4 rounded-lg">
      <div>
        <label className="block text-sm font-medium mb-1">Month</label>
        <input
          type="text"
          value={month}
          onChange={(e) => setMonth(e.target.value)}
          className="w-full p-2 bg-gray-600 rounded focus:ring-2 focus:ring-yellow-500"
          placeholder="e.g., Jan"
        />
      </div>
      <div>
        <label className="block text-sm font-medium mb-1">Inflow</label>
        <input
          type="number"
          value={inflow}
          onChange={(e) => setInflow(e.target.value)}
          className="w-full p-2 bg-gray-600 rounded focus:ring-2 focus:ring-yellow-500"
          placeholder="Enter amount"
        />
      </div>
      <div>
        <label className="block text-sm font-medium mb-1">Outflow</label>
        <input
          type="number"
          value={outflow}
          onChange={(e) => setOutflow(e.target.value)}
          className="w-full p-2 bg-gray-600 rounded focus:ring-2 focus:ring-yellow-500"
          placeholder="Enter amount"
        />
      </div>
      <button
        type="submit"
        className="w-full bg-yellow-500 text-gray-900 py-2 rounded font-medium hover:bg-yellow-400"
      >
        Add Revenue Data
      </button>
    </form>
  );
};