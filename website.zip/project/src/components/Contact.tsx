import React, { useState } from 'react';
import { Phone, Mail, MessageSquare } from 'lucide-react';

export const Contact: React.FC = () => {
  const [message, setMessage] = useState('');
  const [showDialog, setShowDialog] = useState(false);
  const [dialogMessage, setDialogMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setDialogMessage('Thank you for your message! We will get back to you soon.');
    setShowDialog(true);
    setMessage('');
  };

  return (
    <div className="max-w-4xl mx-auto bg-gray-800 p-8 rounded-lg shadow-xl">
      <h2 className="text-3xl font-bold text-yellow-500 mb-8 text-center">Contact Us</h2>
      
      <div className="grid md:grid-cols-2 gap-8 mb-8">
        <div className="space-y-6">
          <div className="flex items-center space-x-4 p-4 bg-gray-700 rounded-lg">
            <Phone className="h-8 w-8 text-yellow-500" />
            <div>
              <h3 className="font-semibold text-lg">Phone</h3>
              <p className="text-gray-300">+91 7978833654</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4 p-4 bg-gray-700 rounded-lg">
            <Mail className="h-8 w-8 text-yellow-500" />
            <div>
              <h3 className="font-semibold text-lg">Email</h3>
              <p className="text-gray-300">subhasishpraharaj52@gmail.com</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Your Message</label>
            <textarea 
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full p-4 bg-gray-700 rounded-lg border border-gray-600 focus:ring-2 focus:ring-yellow-500 focus:border-transparent resize-none"
              rows={6}
              placeholder="Type your message here..."
              required
            />
          </div>
          <button 
            type="submit"
            className="w-full bg-yellow-500 text-gray-900 py-3 px-6 rounded-lg font-medium hover:bg-yellow-400 transition-colors duration-200"
          >
            Send Message
          </button>
        </form>
      </div>

      {/* Dialog */}
      {showDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-gray-800 p-6 rounded-lg max-w-md w-full">
            <div className="flex items-center space-x-3 mb-4">
              <MessageSquare className="text-yellow-500" />
              <h3 className="text-xl font-semibold">Message Sent</h3>
            </div>
            <p className="text-gray-300 mb-4">{dialogMessage}</p>
            <button
              onClick={() => setShowDialog(false)}
              className="w-full bg-yellow-500 text-gray-900 py-2 rounded font-medium hover:bg-yellow-400"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};