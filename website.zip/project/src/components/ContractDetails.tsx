import React, { useState } from 'react';
import { Agreement } from '../types';
import { FileText, AlertTriangle, Calendar, DollarSign } from 'lucide-react';

interface ContractDetailsProps {
  agreement: Agreement;
}

export const ContractDetails: React.FC<ContractDetailsProps> = ({ agreement }) => {
  const [showAnalysis, setShowAnalysis] = useState(false);

  const getEventScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 60) return 'text-yellow-500';
    return 'text-red-500';
  };

  return (
    <div className="bg-gray-800 rounded-lg p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-2xl font-bold text-yellow-500">{agreement.name}</h3>
          <p className="text-gray-400">{agreement.details}</p>
        </div>
        <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
          agreement.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }`}>
          {agreement.status}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gray-700 p-4 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Calendar className="text-yellow-500" />
            <h4 className="font-semibold">Renewal Date</h4>
          </div>
          <p className="text-lg">{agreement.renewalDate}</p>
        </div>

        <div className="bg-gray-700 p-4 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <DollarSign className="text-yellow-500" />
            <h4 className="font-semibold">Value</h4>
          </div>
          <p className="text-lg">${agreement.value.toLocaleString()}</p>
        </div>

        <div className="bg-gray-700 p-4 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <AlertTriangle className="text-yellow-500" />
            <h4 className="font-semibold">Risk Level</h4>
          </div>
          <span className={`px-2 py-1 rounded-full text-sm font-semibold ${
            agreement.riskLevel === 'low' ? 'bg-green-100 text-green-800' :
            agreement.riskLevel === 'medium' ? 'bg-yellow-100 text-yellow-800' :
            'bg-red-100 text-red-800'
          }`}>
            {agreement.riskLevel}
          </span>
        </div>
      </div>

      {agreement.eventScore && (
        <div className="bg-gray-700 p-4 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold">Event Score</h4>
            <span className={`text-2xl font-bold ${getEventScoreColor(agreement.eventScore)}`}>
              {agreement.eventScore}
            </span>
          </div>
          <div className="w-full bg-gray-600 rounded-full h-2">
            <div
              className={`h-2 rounded-full ${
                agreement.eventScore >= 80 ? 'bg-green-500' :
                agreement.eventScore >= 60 ? 'bg-yellow-500' :
                'bg-red-500'
              }`}
              style={{ width: `${agreement.eventScore}%` }}
            />
          </div>
        </div>
      )}

      <button
        onClick={() => setShowAnalysis(!showAnalysis)}
        className="w-full bg-gray-700 hover:bg-gray-600 py-2 rounded-lg flex items-center justify-center space-x-2"
      >
        <FileText className="text-yellow-500" />
        <span>{showAnalysis ? 'Hide Analysis' : 'Show Analysis'}</span>
      </button>

      {showAnalysis && agreement.analysis && (
        <div className="bg-gray-700 p-4 rounded-lg">
          <h4 className="font-semibold mb-2">Contract Analysis</h4>
          <p className="text-gray-300 whitespace-pre-wrap">{agreement.analysis}</p>
        </div>
      )}
    </div>
  );
};